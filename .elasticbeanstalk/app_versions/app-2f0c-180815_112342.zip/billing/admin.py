from django.contrib import admin

from .models import BillingProfile

admin.site.register(BillingProfile)

#admin.site.register(Card)

#admin.site.register(Charge)